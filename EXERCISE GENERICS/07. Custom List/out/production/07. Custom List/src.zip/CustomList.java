import java.util.ArrayList;
import java.util.List;

public class CustomList<T extends Comparable> {
    private List<T> collection;

    public CustomList() {
        this.collection = new ArrayList<>();
    }

    public void add(T element) {
        this.collection.add(element);
    }

    public T remove(int index) {
        return this.collection.remove(index);
    }

    public boolean contains(T element) {
        return this.collection.contains(element);
    }

    public void swap(int firstIndex, int secondIndex) {
        T firstItem = this.collection.get(firstIndex);
        T secondItem = this.collection.get(secondIndex);

        this.collection.set(secondIndex, firstItem);
        this.collection.set(firstIndex, secondItem);
    }

    public long countGreaterThan(T element) {
        long count = 0;
        for (int i = 0; i < this.collection.size(); i++) {
            T currentElement = this.collection.get(i);
            if (currentElement.compareTo(element) > 0) {
                count++;
            }
        }
        return count;
    }

    public T getMax() {
        T element = this.collection.get(0);

        for (int i = 1; i < this.collection.size(); i++) {
            T currentElement = this.collection.get(i);

            if (currentElement.compareTo(element) > 0) {
                element = currentElement;
            }
        }
        return element;
    }

    public T getMin() {
        T element = this.collection.get(0);

        for (int i = 1; i < this.collection.size(); i++) {
            T currentElement = this.collection.get(i);

            if (currentElement.compareTo(element) <= 0) {
                element = currentElement;
            }
        }


        return element;
    }

    public List<T> getCollection(){
        return new ArrayList<>(this.collection);
    }

    public void setCollection(List<T> collection){
        this.collection = collection;
    }

    @Override
    public String toString() {
        StringBuilder output = new StringBuilder();

        for (int i = 0; i < this.collection.size(); i++) {
            output.append(this.collection.get(i)).append("\n");
        }
        return output.toString();
    }
}
